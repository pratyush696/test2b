package com.example.test2;

import javafx.scene.control.TableColumn;

public class RecipeCollection {
    private int RecipeID ;
    private String RecipeName;
    private String Ingredients;
    private TableColumn<RecipeCollection, String> Instructions;
    public RecipeCollection(int RecipeID, String RecipeName, String Ingredients, TableColumn<RecipeCollection, String> Instructions) {
        this.RecipeID = RecipeID;
        this.RecipeName = RecipeName;
        this.Ingredients = Ingredients;
        this.Instructions = Instructions;
    }

    public int getRecipeID() {
        return RecipeID;
    }

    public void setRecipeID(int RecipeID) {
        this.RecipeID = RecipeID;
    }

    public String getRecipeName() {
        return RecipeName;
    }

    public void setRecipeName(String RecipeName) {
        this.RecipeName = RecipeName;
    }

    public String getIngredients() {
        return Ingredients;
    }

    public void setIngredients(String Ingredients) {
        this.Ingredients = Ingredients;
    }

    public TableColumn<RecipeCollection, String> getInstructions() {
        return Instructions;
    }

    public void setInstructions(TableColumn<RecipeCollection, String> Instructions) {
        this.Instructions = Instructions;
    }
}
