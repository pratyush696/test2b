package com.example.test2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;
import java.sql.*;

public class HelloController implements Initializable {
    public TableView<RecipeCollection> RecipeCollection;
    public TableColumn<RecipeCollection, Integer> recipeid;
    public TableColumn<RecipeCollection, String> recipename;
    public TableColumn<RecipeCollection, String> ingredients;
    public TableColumn<RecipeCollection, String> instructions;
    public TextField rid;
    public TextField rname;
    public TextField rIngredients;
    public TextField rInstructions;
    @FXML
    private Label welcomeText;
    ObservableList<RecipeCollection> list = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        recipeid.setCellValueFactory(new
                PropertyValueFactory<RecipeCollection, Integer>("Recipeid"));
        recipename.setCellValueFactory(new
                PropertyValueFactory<RecipeCollection, String>("RecipeName"));
        ingredients.setCellValueFactory(new
                PropertyValueFactory<RecipeCollection, String>("Ingredients"));
        instructions.setCellValueFactory(new
                PropertyValueFactory<RecipeCollection, String>("Instructions"));
        RecipeCollection.setItems(list);
    }

    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }

    public void populateTable() {
        list.clear();
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/test2bpc";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM recipecollection";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("Recipeid");
                String recipename = resultSet.getString("RecipeName");
                String ingredients = resultSet.getString("Ingredients");
                String Instructions = resultSet.getString("Instructions");
                RecipeCollection.getItems().add(new RecipeCollection(id, recipename, ingredients, instructions));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void InsertData(ActionEvent actionEvent) {

        String Recipename = rname.getText();
        String Ingredients = rIngredients.getText();
        String Instructions = rInstructions.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/test2bpc";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `RecipeCollection`( `RecipeName`, `Ingredients`, `Instructions`) VALUES ('"+Recipename+"','"+Ingredients+"','"+Instructions+"')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }




    }

    public void UpdateData(ActionEvent actionEvent) {
        Integer Recipeid = Integer.valueOf(rid.getText());
        String RecipeName= rname.getText();
        String Ingredients = rIngredients.getText();
        String Instructions = rInstructions.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/test2bpc";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `RecipeCollection` SET `RecipeName`='"+RecipeName+"',`Ingredients`='"+Ingredients+"',`Instructions`='"+Instructions+"' WHERE Recipeid='"+Recipeid+"' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {
        Integer id = Integer.valueOf(rid.getText());




        String jdbcUrl = "jdbc:mysql://localhost:3306/test2bpc";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM `RecipeCollection` WHERE Recipeid='"+id+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {
        Integer id = Integer.valueOf(rid.getText());

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2bpc";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM GAME WHERE id='"+id+"'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {

                String Recipename = resultSet.getString("Recipename");
                String Ingredients = resultSet.getString("Ingredients");
                String Instructions = resultSet.getString("Instructions");

                rname.setText(Recipename);
                rIngredients.setText(Ingredients);
                rInstructions.setText(Instructions);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}